import { ReactNode } from "react";

interface OrnamentalBorderProps {
  children: ReactNode;
  className?: string;
}

export function OrnamentalBorder({
  children,
  className = "",
}: OrnamentalBorderProps) {
  return (
    <div className={`relative ${className}`}>
      {/* Corner ornaments */}
      <svg
        className="absolute -top-4 -left-4 w-8 h-8 text-primary"
        viewBox="0 0 32 32"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      >
        <path d="M0 16 Q0 0 16 0" />
        <path d="M4 16 Q4 4 16 4" />
      </svg>
      <svg
        className="absolute -top-4 -right-4 w-8 h-8 text-primary rotate-90"
        viewBox="0 0 32 32"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      >
        <path d="M0 16 Q0 0 16 0" />
        <path d="M4 16 Q4 4 16 4" />
      </svg>
      <svg
        className="absolute -bottom-4 -right-4 w-8 h-8 text-primary rotate-180"
        viewBox="0 0 32 32"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      >
        <path d="M0 16 Q0 0 16 0" />
        <path d="M4 16 Q4 4 16 4" />
      </svg>
      <svg
        className="absolute -bottom-4 -left-4 w-8 h-8 text-primary -rotate-90"
        viewBox="0 0 32 32"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      >
        <path d="M0 16 Q0 0 16 0" />
        <path d="M4 16 Q4 4 16 4" />
      </svg>

      {/* Content */}
      <div className="border-2 border-primary bg-card/50 backdrop-blur-sm p-6">
        {children}
      </div>
    </div>
  );
}
