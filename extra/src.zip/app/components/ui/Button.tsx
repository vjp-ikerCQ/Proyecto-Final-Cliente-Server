import { motion } from "motion/react";
import { ReactNode } from "react";

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "destructive" | "ghost";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  className?: string;
}

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  disabled = false,
  className = "",
}: ButtonProps) {
  const baseStyles =
    "relative overflow-hidden transition-all duration-200 border-2 tracking-wider uppercase";

  const variants = {
    primary:
      "bg-primary text-primary-foreground border-[#a08968] hover:bg-[#9d8567] shadow-[0_0_15px_rgba(139,115,85,0.3)]",
    secondary:
      "bg-secondary text-secondary-foreground border-accent hover:bg-accent",
    destructive:
      "bg-destructive text-destructive-foreground border-[#a03939] hover:bg-[#9d3434]",
    ghost:
      "bg-transparent text-foreground border-border hover:bg-accent/20",
  };

  const sizes = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  };

  return (
    <motion.button
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${
        disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
      } ${className}`}
    >
      <span className="relative z-10">{children}</span>
      <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent opacity-0 hover:opacity-100 transition-opacity" />
    </motion.button>
  );
}
