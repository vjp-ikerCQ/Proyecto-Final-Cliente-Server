import { Heart, Zap } from "lucide-react";

interface ResourceBarProps {
  type: "health" | "energy";
  current: number;
  max: number;
  className?: string;
}

export function ResourceBar({
  type,
  current,
  max,
  className = "",
}: ResourceBarProps) {
  const percentage = (current / max) * 100;

  const config = {
    health: {
      icon: Heart,
      color: "#8b2c2c",
      bgColor: "#2a1414",
      label: "Vida",
    },
    energy: {
      icon: Zap,
      color: "#4a5fa8",
      bgColor: "#1a1f3a",
      label: "Voluntad",
    },
  };

  const { icon: Icon, color, bgColor, label } = config[type];

  return (
    <div className={`flex flex-col gap-1 ${className}`}>
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-2">
          <Icon size={16} style={{ color }} fill={color} />
          <span className="text-muted-foreground">{label}</span>
        </div>
        <span className="font-['Cinzel']">
          {current} / {max}
        </span>
      </div>
      <div
        className="h-6 rounded-sm border-2 overflow-hidden relative"
        style={{ borderColor: color, backgroundColor: bgColor }}
      >
        <div
          className="h-full transition-all duration-300"
          style={{
            width: `${percentage}%`,
            backgroundColor: color,
            boxShadow: `0 0 10px ${color}`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />
      </div>
    </div>
  );
}
