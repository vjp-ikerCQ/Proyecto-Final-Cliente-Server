import { motion } from "motion/react";
import { ReactNode } from "react";
import { Sword, Heart, Coins, TreePine } from "lucide-react";

export type SuitType = "espadas" | "copas" | "oros" | "bastos";

interface GameCardProps {
  name: string;
  suit: SuitType;
  cost: number;
  attack: number;
  health: number;
  ability?: string;
  rarity?: "common" | "rare" | "epic" | "legendary";
  onClick?: () => void;
  isPlayable?: boolean;
  className?: string;
}

const suitConfig = {
  espadas: {
    color: "#c41e3a",
    icon: Sword,
    name: "Espadas",
    gradient: "from-red-900/20 to-red-950/40",
  },
  copas: {
    color: "#8b2c8b",
    icon: Heart,
    name: "Copas",
    gradient: "from-purple-900/20 to-purple-950/40",
  },
  oros: {
    color: "#d4af37",
    icon: Coins,
    name: "Oros",
    gradient: "from-yellow-700/20 to-yellow-900/40",
  },
  bastos: {
    color: "#2d5016",
    icon: TreePine,
    name: "Bastos",
    gradient: "from-green-900/20 to-green-950/40",
  },
};

const rarityConfig = {
  common: { border: "#4a4a5a", glow: "rgba(74, 74, 90, 0.2)" },
  rare: { border: "#4a7ba7", glow: "rgba(74, 123, 167, 0.3)" },
  epic: { border: "#8b4a9d", glow: "rgba(139, 74, 157, 0.4)" },
  legendary: { border: "#d4af37", glow: "rgba(212, 175, 55, 0.5)" },
};

export function GameCard({
  name,
  suit,
  cost,
  attack,
  health,
  ability,
  rarity = "common",
  onClick,
  isPlayable = false,
  className = "",
}: GameCardProps) {
  const SuitIcon = suitConfig[suit].icon;
  const { border, glow } = rarityConfig[rarity];

  return (
    <motion.div
      whileHover={{ scale: isPlayable ? 1.05 : 1.02, y: isPlayable ? -8 : 0 }}
      whileTap={{ scale: isPlayable ? 0.95 : 1 }}
      onClick={isPlayable ? onClick : undefined}
      className={`relative w-40 h-56 bg-gradient-to-b ${
        suitConfig[suit].gradient
      } rounded-sm border-2 ${
        isPlayable ? "cursor-pointer" : "cursor-default"
      } ${className}`}
      style={{
        borderColor: border,
        boxShadow: `0 0 20px ${glow}, inset 0 0 30px rgba(0,0,0,0.3)`,
      }}
    >
      {/* Ornamental corners */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-primary" />
      <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-primary" />
      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-primary" />
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-primary" />

      {/* Cost badge */}
      <div
        className="absolute -top-3 -left-3 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2"
        style={{
          backgroundColor: "#1a1a22",
          borderColor: suitConfig[suit].color,
          color: suitConfig[suit].color,
        }}
      >
        {cost}
      </div>

      {/* Card content */}
      <div className="p-3 h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-2 mb-2">
          <SuitIcon
            size={16}
            style={{ color: suitConfig[suit].color }}
            strokeWidth={2.5}
          />
          <h4 className="text-xs text-foreground truncate flex-1 font-['Cinzel']">
            {name}
          </h4>
        </div>

        {/* Artwork placeholder */}
        <div className="flex-1 bg-black/40 rounded-sm border border-border/30 mb-2 flex items-center justify-center">
          <SuitIcon
            size={48}
            style={{ color: suitConfig[suit].color, opacity: 0.3 }}
            strokeWidth={1.5}
          />
        </div>

        {/* Ability */}
        {ability && (
          <p className="text-[10px] text-muted-foreground mb-2 line-clamp-2 italic">
            {ability}
          </p>
        )}

        {/* Stats */}
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-1">
            <Sword size={12} className="text-destructive" />
            <span className="text-sm">{attack}</span>
          </div>
          <div className="flex items-center gap-1">
            <Heart size={12} className="text-health" fill="#8b2c2c" />
            <span className="text-sm">{health}</span>
          </div>
        </div>
      </div>

      {/* Rarity indicator */}
      <div
        className="absolute bottom-1 left-1/2 -translate-x-1/2 w-12 h-0.5"
        style={{ backgroundColor: border }}
      />
    </motion.div>
  );
}

interface CardBackProps {
  className?: string;
}

export function CardBack({ className = "" }: CardBackProps) {
  return (
    <div
      className={`w-40 h-56 bg-gradient-to-br from-primary/20 to-primary/5 rounded-sm border-2 border-primary relative ${className}`}
      style={{
        boxShadow: "0 0 15px rgba(139,115,85,0.2), inset 0 0 30px rgba(0,0,0,0.4)",
      }}
    >
      <div className="absolute inset-2 border border-primary/50 rounded-sm flex items-center justify-center">
        <h2 className="font-['Cinzel_Decorative'] text-primary text-xl tracking-widest">
          RH
        </h2>
      </div>
    </div>
  );
}
