import { motion } from "motion/react";
import { GameCard, SuitType } from "./ui/Card";
import { allCards, getCardsBySuit } from "../data/cards";
import { useState } from "react";
import { Button } from "./ui/Button";
import { ArrowLeft } from "lucide-react";

interface CardGalleryProps {
  onBack?: () => void;
}

export function CardGallery({ onBack }: CardGalleryProps) {
  const [selectedSuit, setSelectedSuit] = useState<SuitType | "all">("all");

  const filteredCards =
    selectedSuit === "all" ? allCards : getCardsBySuit(selectedSuit);

  const suits: Array<{ value: SuitType | "all"; label: string; color: string }> = [
    { value: "all", label: "Todas", color: "#8b7355" },
    { value: "espadas", label: "Espadas", color: "#c41e3a" },
    { value: "copas", label: "Copas", color: "#8b2c8b" },
    { value: "oros", label: "Oros", color: "#d4af37" },
    { value: "bastos", label: "Bastos", color: "#2d5016" },
  ];

  return (
    <div className="size-full bg-gradient-to-b from-background via-primary/5 to-background overflow-auto">
      <div className="max-w-7xl mx-auto p-8">
        {/* Back button */}
        {onBack && (
          <div className="mb-6">
            <Button
              onClick={onBack}
              variant="ghost"
              size="sm"
              className="flex items-center gap-2"
            >
              <ArrowLeft size={16} />
              <span>Volver al Menú</span>
            </Button>
          </div>
        )}

        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="font-['Cinzel_Decorative'] text-4xl mb-4 text-primary tracking-widest">
            GALERÍA DE CARTAS
          </h1>
          <p className="text-muted-foreground mb-6">
            48 cartas únicas de la baraja española
          </p>

          {/* Filter buttons */}
          <div className="flex justify-center gap-3 flex-wrap">
            {suits.map((suit) => (
              <button
                key={suit.value}
                onClick={() => setSelectedSuit(suit.value)}
                className={`px-4 py-2 rounded-sm border-2 transition-all font-['Cinzel'] ${
                  selectedSuit === suit.value
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground border-border hover:border-primary/50"
                }`}
                style={
                  selectedSuit === suit.value
                    ? { borderColor: suit.color, backgroundColor: suit.color }
                    : {}
                }
              >
                {suit.label}
              </button>
            ))}
          </div>
        </div>

        {/* Cards grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 justify-items-center"
        >
          {filteredCards.map((card, index) => (
            <motion.div
              key={card.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.02 }}
            >
              <GameCard {...card} />
            </motion.div>
          ))}
        </motion.div>

        {/* Stats */}
        <div className="mt-12 text-center">
          <div className="inline-flex gap-8 px-8 py-4 bg-card/30 backdrop-blur-sm border border-border rounded-sm">
            <div>
              <div className="text-2xl font-['Cinzel'] text-primary">
                {filteredCards.length}
              </div>
              <div className="text-xs text-muted-foreground">Cartas</div>
            </div>
            <div className="w-px bg-border" />
            <div>
              <div className="text-2xl font-['Cinzel'] text-primary">4</div>
              <div className="text-xs text-muted-foreground">Palos</div>
            </div>
            <div className="w-px bg-border" />
            <div>
              <div className="text-2xl font-['Cinzel'] text-primary">48</div>
              <div className="text-xs text-muted-foreground">Total</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
