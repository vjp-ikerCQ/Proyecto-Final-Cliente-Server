import { useState } from "react";
import { SplashScreen } from "./screens/SplashScreen";
import { LoginScreen } from "./screens/LoginScreen";
import { MainMenuScreen } from "./screens/MainMenuScreen";
import { GameScreen } from "./screens/GameScreen";
import { ResultScreen } from "./screens/ResultScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { CardGallery } from "./components/CardGallery";

type Screen =
  | "splash"
  | "login"
  | "menu"
  | "game"
  | "result"
  | "settings"
  | "gallery";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("splash");
  const [username, setUsername] = useState("Invitado");
  const [gameResult, setGameResult] = useState(false);

  const handleLogin = (name: string) => {
    setUsername(name);
    setCurrentScreen("menu");
  };

  const handleGuest = () => {
    setUsername("Invitado");
    setCurrentScreen("menu");
  };

  const handleStartGame = () => {
    setCurrentScreen("game");
  };

  const handleGameEnd = (victory: boolean) => {
    setGameResult(victory);
    setCurrentScreen("result");
  };

  const handlePlayAgain = () => {
    setCurrentScreen("game");
  };

  const handleMainMenu = () => {
    setCurrentScreen("menu");
  };

  const handleSettings = () => {
    setCurrentScreen("settings");
  };

  const handleLogout = () => {
    setUsername("Invitado");
    setCurrentScreen("login");
  };

  const handleQuitGame = () => {
    setCurrentScreen("menu");
  };

  const handleGallery = () => {
    setCurrentScreen("gallery");
  };

  return (
    <div className="size-full">
      {currentScreen === "splash" && (
        <SplashScreen onComplete={() => setCurrentScreen("login")} />
      )}

      {currentScreen === "login" && (
        <LoginScreen onLogin={handleLogin} onGuest={handleGuest} />
      )}

      {currentScreen === "menu" && (
        <MainMenuScreen
          username={username}
          onStartGame={handleStartGame}
          onSettings={handleSettings}
          onLogout={handleLogout}
          onGallery={handleGallery}
        />
      )}

      {currentScreen === "game" && (
        <GameScreen onGameEnd={handleGameEnd} onQuit={handleQuitGame} />
      )}

      {currentScreen === "result" && (
        <ResultScreen
          victory={gameResult}
          onPlayAgain={handlePlayAgain}
          onMainMenu={handleMainMenu}
        />
      )}

      {currentScreen === "settings" && (
        <SettingsScreen onBack={handleMainMenu} />
      )}

      {currentScreen === "gallery" && <CardGallery onBack={handleMainMenu} />}
    </div>
  );
}