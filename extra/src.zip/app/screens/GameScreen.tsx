import { motion } from "motion/react";
import { useState } from "react";
import { GameCard, CardBack, SuitType } from "../components/ui/Card";
import { ResourceBar } from "../components/ui/ResourceBar";
import { Button } from "../components/ui/Button";
import { Shield, Swords } from "lucide-react";

interface GameScreenProps {
  onGameEnd: (victory: boolean) => void;
  onQuit: () => void;
}

// Sample cards data
const sampleCards = [
  {
    id: 1,
    name: "As de Espadas",
    suit: "espadas" as SuitType,
    cost: 3,
    attack: 5,
    health: 3,
    ability: "Crítico: Doble daño al atacar",
    rarity: "legendary" as const,
  },
  {
    id: 2,
    name: "Dos de Copas",
    suit: "copas" as SuitType,
    cost: 2,
    attack: 1,
    health: 3,
    ability: "Cura 2 de vida al entrar",
    rarity: "common" as const,
  },
  {
    id: 3,
    name: "Rey de Oros",
    suit: "oros" as SuitType,
    cost: 4,
    attack: 3,
    health: 5,
    ability: "+1 Voluntad cada turno",
    rarity: "epic" as const,
  },
  {
    id: 4,
    name: "Caballo de Bastos",
    suit: "bastos" as SuitType,
    cost: 3,
    attack: 2,
    health: 6,
    ability: "Protección: Reduce daño en 1",
    rarity: "rare" as const,
  },
  {
    id: 5,
    name: "Tres de Espadas",
    suit: "espadas" as SuitType,
    cost: 2,
    attack: 3,
    health: 2,
    ability: "Ataque rápido",
    rarity: "common" as const,
  },
];

export function GameScreen({ onGameEnd, onQuit }: GameScreenProps) {
  const [playerHealth, setPlayerHealth] = useState(30);
  const [enemyHealth, setEnemyHealth] = useState(30);
  const [playerEnergy, setPlayerEnergy] = useState(3);
  const [turn, setTurn] = useState(1);
  const [hand] = useState(sampleCards.slice(0, 5));
  const [playerField] = useState(sampleCards.slice(0, 2));
  const [enemyField] = useState(sampleCards.slice(2, 4));

  const endTurn = () => {
    setTurn(turn + 1);
    setPlayerEnergy(Math.min(10, turn + 3));
  };

  return (
    <div className="size-full bg-gradient-to-b from-background via-primary/5 to-background flex flex-col">
      {/* Top bar - Enemy info */}
      <div className="p-4 bg-card/30 backdrop-blur-sm border-b border-border">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-destructive/20 border-2 border-destructive flex items-center justify-center">
              <Shield size={24} className="text-destructive" />
            </div>
            <div>
              <h3 className="font-['Cinzel'] mb-1">Enemigo Oscuro</h3>
              <ResourceBar type="health" current={enemyHealth} max={30} className="w-64" />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Turno</div>
              <div className="text-xl font-['Cinzel']">{turn}</div>
            </div>
            <Button onClick={onQuit} variant="ghost" size="sm">
              Rendirse
            </Button>
          </div>
        </div>
      </div>

      {/* Main game area */}
      <div className="flex-1 flex flex-col justify-between p-6 overflow-hidden">
        <div className="max-w-7xl mx-auto w-full space-y-6">
          {/* Enemy field */}
          <div className="flex justify-center gap-4 min-h-[240px] items-end">
            {enemyField.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ y: -50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <GameCard {...card} />
              </motion.div>
            ))}
            {enemyField.length === 0 && (
              <div className="text-muted-foreground text-sm italic">
                Campo enemigo vacío
              </div>
            )}
          </div>

          {/* Combat zone indicator */}
          <div className="relative">
            <div className="h-px bg-gradient-to-r from-transparent via-primary to-transparent" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-4">
              <Swords size={20} className="text-primary" />
            </div>
          </div>

          {/* Player field */}
          <div className="flex justify-center gap-4 min-h-[240px] items-start">
            {playerField.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <GameCard {...card} />
              </motion.div>
            ))}
            {playerField.length === 0 && (
              <div className="text-muted-foreground text-sm italic">
                Tu campo está vacío
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom bar - Player info and hand */}
      <div className="bg-card/30 backdrop-blur-sm border-t border-border">
        {/* Player resources */}
        <div className="p-4 border-b border-border/50">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center">
                <Shield size={24} className="text-primary" />
              </div>
              <div className="flex gap-6">
                <ResourceBar type="health" current={playerHealth} max={30} className="w-48" />
                <ResourceBar type="energy" current={playerEnergy} max={10} className="w-48" />
              </div>
            </div>
            <Button onClick={endTurn} variant="primary" size="lg">
              Finalizar Turno
            </Button>
          </div>
        </div>

        {/* Player hand */}
        <div className="p-4 overflow-x-auto">
          <div className="max-w-7xl mx-auto flex justify-center gap-3">
            {hand.map((card, index) => (
              <motion.div
                key={card.id}
                initial={{ y: 100, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 + 0.3 }}
              >
                <GameCard {...card} isPlayable={card.cost <= playerEnergy} />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
