import { motion } from "motion/react";
import { Button } from "../components/ui/Button";
import { Trophy, Skull, RotateCcw, Home } from "lucide-react";
import { OrnamentalBorder } from "../components/layout/OrnamentalBorder";

interface ResultScreenProps {
  victory: boolean;
  onPlayAgain: () => void;
  onMainMenu: () => void;
}

export function ResultScreen({
  victory,
  onPlayAgain,
  onMainMenu,
}: ResultScreenProps) {
  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-b from-background via-background to-primary/5 p-8">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-lg"
      >
        <div className="text-center mb-8">
          <motion.div
            initial={{ y: -30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="mb-6"
          >
            {victory ? (
              <Trophy
                size={80}
                className="mx-auto text-[#d4af37]"
                strokeWidth={1.5}
              />
            ) : (
              <Skull
                size={80}
                className="mx-auto text-destructive"
                strokeWidth={1.5}
              />
            )}
          </motion.div>

          <motion.h1
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="font-['Cinzel_Decorative'] text-5xl mb-4 text-primary tracking-widest"
          >
            {victory ? "VICTORIA" : "DERROTA"}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="text-muted-foreground font-['Cinzel']"
          >
            {victory
              ? "Has conquistado el reino con honor"
              : "El reino cayó ante las sombras"}
          </motion.p>
        </div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.6 }}
        >
          <OrnamentalBorder>
            <div className="space-y-4">
              {/* Game stats */}
              <div className="grid grid-cols-3 gap-4 pb-4 border-b border-border">
                <div className="text-center">
                  <div className="text-2xl font-['Cinzel'] text-primary">12</div>
                  <div className="text-xs text-muted-foreground">Turnos</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-['Cinzel'] text-primary">8</div>
                  <div className="text-xs text-muted-foreground">Cartas</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-['Cinzel'] text-primary">24</div>
                  <div className="text-xs text-muted-foreground">Daño</div>
                </div>
              </div>

              {/* Rewards (if victory) */}
              {victory && (
                <div className="py-4 border-b border-border">
                  <h3 className="text-center mb-3 text-sm text-muted-foreground">
                    Recompensas
                  </h3>
                  <div className="flex justify-center gap-6">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-[#d4af37]/20 border border-[#d4af37] flex items-center justify-center">
                        <span className="text-[#d4af37]">◆</span>
                      </div>
                      <span className="text-sm">+150 Oro</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy size={16} className="text-primary" />
                      <span className="text-sm">+50 Exp</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Action buttons */}
              <div className="space-y-3 pt-2">
                <Button
                  onClick={onPlayAgain}
                  variant="primary"
                  size="lg"
                  className="w-full flex items-center justify-center gap-3"
                >
                  <RotateCcw size={20} />
                  <span>Jugar de Nuevo</span>
                </Button>

                <Button
                  onClick={onMainMenu}
                  variant="secondary"
                  size="md"
                  className="w-full flex items-center justify-center gap-3"
                >
                  <Home size={18} />
                  <span>Menú Principal</span>
                </Button>
              </div>
            </div>
          </OrnamentalBorder>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="text-center mt-6 text-xs text-muted-foreground italic"
        >
          {victory
            ? '"La victoria pertenece a los valientes"'
            : '"Levántate y vuelve a intentarlo"'}
        </motion.p>
      </motion.div>
    </div>
  );
}
