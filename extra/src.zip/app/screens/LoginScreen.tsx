import { motion } from "motion/react";
import { Button } from "../components/ui/Button";
import { OrnamentalBorder } from "../components/layout/OrnamentalBorder";
import { useState } from "react";

interface LoginScreenProps {
  onLogin: (username: string) => void;
  onGuest: () => void;
}

export function LoginScreen({ onLogin, onGuest }: LoginScreenProps) {
  const [username, setUsername] = useState("");

  const handleLogin = () => {
    if (username.trim()) {
      onLogin(username.trim());
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-b from-background via-background to-primary/5 p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <h1 className="font-['Cinzel_Decorative'] text-5xl text-center mb-2 text-primary tracking-widest">
          REGNUM HOLLOW
        </h1>
        <p className="text-center text-muted-foreground mb-12 font-['Cinzel'] tracking-wider">
          In Manus Fatum
        </p>

        <OrnamentalBorder>
          <div className="space-y-6">
            <div>
              <label className="block mb-2 text-sm text-muted-foreground">
                Nombre de Caballero
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleLogin()}
                placeholder="Ingresa tu nombre..."
                className="w-full px-4 py-3 bg-input-background border-2 border-border rounded-sm text-foreground focus:border-primary focus:outline-none transition-colors"
              />
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleLogin}
                variant="primary"
                size="lg"
                className="w-full"
                disabled={!username.trim()}
              >
                Entrar al Reino
              </Button>

              <Button
                onClick={onGuest}
                variant="ghost"
                size="md"
                className="w-full"
              >
                Continuar como Invitado
              </Button>
            </div>
          </div>
        </OrnamentalBorder>

        <div className="mt-8 text-center text-xs text-muted-foreground">
          <p>Un proyecto de DAW - 2026</p>
          <p className="mt-1">Cuatro palos. Un solo reino.</p>
        </div>
      </motion.div>
    </div>
  );
}
