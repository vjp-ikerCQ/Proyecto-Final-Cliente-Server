import { motion } from "motion/react";
import { Button } from "../components/ui/Button";
import { OrnamentalBorder } from "../components/layout/OrnamentalBorder";
import { Volume2, VolumeX, Music, ArrowLeft } from "lucide-react";
import { useState } from "react";

interface SettingsScreenProps {
  onBack: () => void;
}

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [volume, setVolume] = useState(70);

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-b from-background via-background to-primary/5 p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl"
      >
        <div className="mb-8">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="flex items-center gap-2 mb-4"
          >
            <ArrowLeft size={16} />
            <span>Volver</span>
          </Button>

          <h1 className="font-['Cinzel_Decorative'] text-4xl text-primary tracking-widest">
            AJUSTES
          </h1>
        </div>

        <OrnamentalBorder>
          <div className="space-y-6">
            {/* Audio settings */}
            <div>
              <h3 className="font-['Cinzel'] mb-4 pb-2 border-b border-border">
                Audio
              </h3>

              <div className="space-y-4">
                {/* Master volume */}
                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">
                    Volumen General
                  </label>
                  <div className="flex items-center gap-4">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={volume}
                      onChange={(e) => setVolume(Number(e.target.value))}
                      className="w-48"
                    />
                    <span className="text-sm w-12 text-right">{volume}%</span>
                  </div>
                </div>

                {/* Sound effects */}
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-sm text-muted-foreground">
                    {soundEnabled ? (
                      <Volume2 size={16} className="text-primary" />
                    ) : (
                      <VolumeX size={16} className="text-muted-foreground" />
                    )}
                    <span>Efectos de Sonido</span>
                  </label>
                  <button
                    onClick={() => setSoundEnabled(!soundEnabled)}
                    className={`w-12 h-6 rounded-full border-2 transition-colors relative ${
                      soundEnabled
                        ? "bg-primary border-primary"
                        : "bg-muted border-border"
                    }`}
                  >
                    <div
                      className={`absolute top-0.5 w-4 h-4 bg-background rounded-full transition-transform ${
                        soundEnabled ? "translate-x-6" : "translate-x-0.5"
                      }`}
                    />
                  </button>
                </div>

                {/* Music */}
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Music size={16} className={musicEnabled ? "text-primary" : "text-muted-foreground"} />
                    <span>Música</span>
                  </label>
                  <button
                    onClick={() => setMusicEnabled(!musicEnabled)}
                    className={`w-12 h-6 rounded-full border-2 transition-colors relative ${
                      musicEnabled
                        ? "bg-primary border-primary"
                        : "bg-muted border-border"
                    }`}
                  >
                    <div
                      className={`absolute top-0.5 w-4 h-4 bg-background rounded-full transition-transform ${
                        musicEnabled ? "translate-x-6" : "translate-x-0.5"
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Graphics settings */}
            <div>
              <h3 className="font-['Cinzel'] mb-4 pb-2 border-b border-border">
                Gráficos
              </h3>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">
                    Calidad de Animaciones
                  </label>
                  <select className="px-4 py-2 bg-input-background border-2 border-border rounded-sm text-foreground focus:border-primary focus:outline-none">
                    <option>Alta</option>
                    <option>Media</option>
                    <option>Baja</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">
                    Efectos de Partículas
                  </label>
                  <button className="w-12 h-6 rounded-full border-2 bg-primary border-primary transition-colors relative">
                    <div className="absolute top-0.5 w-4 h-4 bg-background rounded-full translate-x-6" />
                  </button>
                </div>
              </div>
            </div>

            {/* Game settings */}
            <div>
              <h3 className="font-['Cinzel'] mb-4 pb-2 border-b border-border">
                Juego
              </h3>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">
                    Mostrar Consejos
                  </label>
                  <button className="w-12 h-6 rounded-full border-2 bg-primary border-primary transition-colors relative">
                    <div className="absolute top-0.5 w-4 h-4 bg-background rounded-full translate-x-6" />
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">
                    Velocidad de Animaciones
                  </label>
                  <select className="px-4 py-2 bg-input-background border-2 border-border rounded-sm text-foreground focus:border-primary focus:outline-none">
                    <option>Normal</option>
                    <option>Rápida</option>
                    <option>Instantánea</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-border flex gap-3">
              <Button variant="primary" size="md" className="flex-1">
                Guardar Cambios
              </Button>
              <Button variant="ghost" size="md" className="flex-1">
                Restaurar Predeterminados
              </Button>
            </div>
          </div>
        </OrnamentalBorder>

        <div className="mt-6 text-center text-xs text-muted-foreground">
          <p>Regnum Hollow v1.0.0</p>
          <p className="mt-1">© 2026 - Proyecto DAW</p>
        </div>
      </motion.div>
    </div>
  );
}
