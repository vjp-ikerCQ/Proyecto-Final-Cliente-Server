import { motion } from "motion/react";
import { Button } from "../components/ui/Button";
import { Sword, Settings, Trophy, BookOpen, LogOut } from "lucide-react";

interface MainMenuScreenProps {
  username: string;
  onStartGame: () => void;
  onSettings: () => void;
  onLogout: () => void;
  onGallery?: () => void;
}

export function MainMenuScreen({
  username,
  onStartGame,
  onSettings,
  onLogout,
  onGallery,
}: MainMenuScreenProps) {
  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-b from-background via-background to-primary/5 p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-2xl"
      >
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            initial={{ y: -20 }}
            animate={{ y: 0 }}
            className="font-['Cinzel_Decorative'] text-5xl mb-4 text-primary tracking-widest"
          >
            REGNUM HOLLOW
          </motion.h1>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-16 h-0.5 bg-primary/50" />
            <span className="text-muted-foreground">Bienvenido, {username}</span>
            <div className="w-16 h-0.5 bg-primary/50" />
          </div>
        </div>

        {/* Menu options */}
        <div className="space-y-4 max-w-md mx-auto">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <Button
              onClick={onStartGame}
              variant="primary"
              size="lg"
              className="w-full flex items-center justify-center gap-3"
            >
              <Sword size={20} />
              <span>Nueva Partida</span>
            </Button>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Button
              onClick={() => {}}
              variant="secondary"
              size="lg"
              className="w-full flex items-center justify-center gap-3"
              disabled
            >
              <Trophy size={20} />
              <span>Rankings</span>
            </Button>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Button
              onClick={onGallery}
              variant="secondary"
              size="lg"
              className="w-full flex items-center justify-center gap-3"
            >
              <BookOpen size={20} />
              <span>Galería de Cartas</span>
            </Button>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <Button
              onClick={onSettings}
              variant="secondary"
              size="lg"
              className="w-full flex items-center justify-center gap-3"
            >
              <Settings size={20} />
              <span>Ajustes</span>
            </Button>
          </motion.div>

          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <Button
              onClick={onLogout}
              variant="ghost"
              size="md"
              className="w-full flex items-center justify-center gap-3"
            >
              <LogOut size={18} />
              <span>Salir</span>
            </Button>
          </motion.div>
        </div>

        {/* Suit icons decoration */}
        <div className="mt-16 flex justify-center gap-8 opacity-30">
          <Sword size={24} className="text-[#c41e3a]" />
          <div className="text-[#8b2c8b]">♥</div>
          <div className="text-[#d4af37]">◆</div>
          <div className="text-[#2d5016]">♣</div>
        </div>

        <p className="text-center mt-8 text-xs text-muted-foreground italic">
          "La baraja decidirá tu reino"
        </p>
      </motion.div>
    </div>
  );
}
